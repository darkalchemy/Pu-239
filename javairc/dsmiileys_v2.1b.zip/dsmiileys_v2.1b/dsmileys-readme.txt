Thema's Dsmileys plugin v2.0

There really isn't a lot to say about this new docked smiley plugin.
There's only two parameters to configure, and you don't really need those for most applets.

Just add the dsmileys.jar, and/or dsmileys.cab to your applet code:
It will use the same smilies you configure in your applet. No more javascript or PHP buttons.
Duplicate inages are checked for and will only be displayed once.

<applet name="PJirc" code=IRCApplet.class archive="irc.jar,pixx.jar,dsmileys.jar" width=640 height=450>
<param name="CABINETS" value="irc.cab,securedirc.cab,pixx.cab,dsmileys.cab">
<param name="plugin1" value="adnd.DSmileys">

You will see a new Smiley panel docked to the bottom of the applet.
Hitting a smiley will send that code to the source.

All you do is set up the applet with some smileys, the rest is done for you.

The Smiley panel will automatically set itself up with scrollbars,
and will size itself to 20% of the applet's height.
I will be adding parameters to alter this later.

Parameters:

dsmileys:columns
Sets the number of columns across the screen. The smileys will spread out to fill the panel.
This param defaults to 30. This can help to organise your scrollbars. More columns means you are less
likley to have a side scrollbar. Fewer columns means you are less likely to see a bottom scrollbar.

Example:
<param name="dsmileys:columns" value="30">

dsmileys:height
Sets the height, in pixels, to be used for the Smiley panel. This will be subtracted from the overall height of the applet,
and defaults to 20% of the applet height should a silly number get chosen.

Example:
<param name="dsmileys:height" value="100">


dsmileys:bkgcolor
Sets the background color of the Smiley panel according to the sourcecolorrule colors. 
The value is a number from 0 to 15.
This param defaults to 2.

Example:
<param name="dsmileys:bkgcolor" value="11">

Known bugs are:
An inability to send smileys to undocked sources. I doubt if I'll ever fix this one.
I'm not sure how it turns out if you customise using the sourcecolorrule parameter.


Please send in your bug reports, comments, etc. to thema@adnd.com or post them to the PJirc forums.