/******************************************************/
/*          This java file is a part of the           */
/*                                                    */
/*      -  ADnD.com DSmileys v2.1b Plugin for -       */
/*                                                    */
/*                    -  PJirc -                      */
/*                                                    */
/*            - Plouf's Java IRC Client  -            */
/*                                                    */
/* Copyright (C)  2002 - 2006 Thema Ardholla Derentil */
/*                                                    */
/*         All contacts : thema@adnd.com              */
/*                                                    */
/*  This is free software; you can redistribute       */
/*  it and/or modify it under the terms of the GNU    */
/*  General Public License as published by the        */
/*  Free Software Foundation; version 2 or later of   */
/*  the License.                                      */
/*                                                    */
/*  It is distributed in the hope that it will        */
/*  be useful, but WITHOUT ANY WARRANTY; without      */
/*  even the implied warranty of MERCHANTABILITY or   */
/*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    */
/*  General Public License for more details.          */
/*                                                    */
/*  You should have received a copy of the GNU        */
/*  General Public License along with PJIRC; if       */
/*  not, write to the Free Software Foundation,       */
/*  Inc., 59 Temple Place, Suite 330, Boston,         */
/*  MA  02111-1307  USA                               */
/*                                                    */
/******************************************************/

package irc.plugin.adnd;

import irc.*;
import irc.plugin.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;


public class DSmileyButtons extends WindowAdapter implements ActionListener,Runnable 
{
	private Thread _thread=null;
	private Panel _panel;
	private Color _bkgColor;
	private int _cols;
	private IRCApplication _appl;
	private IRCConfiguration _config;
	private SmileyTable _dsmileyTable;
	private DSmileyConfiguration _dsConfig;
	private boolean _loaded=false;
	
	public DSmileyButtons(IRCConfiguration config, DSmileyConfiguration dsConfig, IRCApplication appl)
	{
		_appl=appl;
		_config=config;
		_dsConfig=dsConfig;
		Color[] _colors=_config.getStyleColors(_config.getDefaultStyleContext());
		_bkgColor=_colors[_dsConfig.getI("bkgcolor")];
		_dsmileyTable=_config.getSmileyTable();
		_cols=(int)_dsConfig.getI("columns");

		if (_thread == null) 
		{
			_thread = new Thread(this, "DSmiley_Picker");
			_thread.setDaemon(true);
			_thread.start();
		}
	}

	
	
	public void run() 
	{
		Thread myThread=Thread.currentThread();
		_panel=new Panel();
		_panel.setLayout(new GridLayout(0,_cols));
		_panel.setBackground(_bkgColor);

		int s=_dsmileyTable.getSize();
		for(int i=0;i<s;i++)
		{
			Image img=_dsmileyTable.getImage(i);
			boolean unique=true;
			for(int j=0;j<i;j++)
			{
				Image img1=_dsmileyTable.getImage(j);
				if (img == img1) unique=false;
			}
			if (unique)
			{
				String str=_dsmileyTable.getMatch(i);
				DSmileyButton button;
				button = new DSmileyButton(img);
				button.waitForDSmiley(true);
				while (!button.isLoaded())
				{
					try 
					{
						_thread.sleep(10);
					}
					catch (InterruptedException e) 
					{
					}
				}
				button.setBorder(button.getBorder() - 2);
				button.setDSmileyID(str);
				button.addActionListener(this);
				_panel.add(button);
			}
		}
			_loaded=!_loaded;
	}
	
	public boolean loaded()
	{
		return _loaded;
	}

	public void unload() 
	{
		_panel=null;
        _thread = null;
    }
	
	public Panel getButtons()
	{
		return _panel;
	}

	public void actionPerformed(ActionEvent e)
	{	 
		EventDispatcher.dispatchEventAsync(this,"actionPerformedEff",new Object[] {e});
	}
	
	/**
	 * Internally used.
	 */
	public void actionPerformedEff(ActionEvent e)
	{
		String cmd=e.getActionCommand();
		_appl.setFieldText(_appl.getFieldText() + cmd);
		_appl.requestSourceFocus();
	}
}
