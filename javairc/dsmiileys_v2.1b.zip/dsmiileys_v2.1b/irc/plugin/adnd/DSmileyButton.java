/******************************************************/
/*          This java file is a part of the           */
/*                                                    */
/*      -  ADnD.com DSmileys v2.1b Plugin for -       */
/*                                                    */
/*                    -  PJirc -                      */
/*                                                    */
/*            - Plouf's Java IRC Client  -            */
/*                                                    */
/* Copyright (C)  2002 - 2006 Thema Ardholla Derentil */
/*                                                    */
/*         All contacts : thema@adnd.com              */
/*                                                    */
/*  This is free software; you can redistribute       */
/*  it and/or modify it under the terms of the GNU    */
/*  General Public License as published by the        */
/*  Free Software Foundation; version 2 or later of   */
/*  the License.                                      */
/*                                                    */
/*  It is distributed in the hope that it will        */
/*  be useful, but WITHOUT ANY WARRANTY; without      */
/*  even the implied warranty of MERCHANTABILITY or   */
/*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    */
/*  General Public License for more details.          */
/*                                                    */
/*  You should have received a copy of the GNU        */
/*  General Public License along with PJIRC; if       */
/*  not, write to the Free Software Foundation,       */
/*  Inc., 59 Temple Place, Suite 330, Boston,         */
/*  MA  02111-1307  USA                               */
/*                                                    */
/******************************************************/
package irc.plugin.adnd;

import irc.*;
import irc.plugin.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.awt.image.*;     // For DSmileyFilter stuff

//======================================================
/**
 * A button class that uses a dsmiley instead of a
 * textual label. Clicking and releasing the mouse over
 * the button triggers an ACTION_EVENT, so you can add
 * behavior in the same two ways as you with a normal
 * Button (in Java 1.0):
 * <OL>
 *  <LI>Make an DSmileyButton subclass and put the
 *      behavior in the action method of that subclass.
 *  <LI>Use the main DSmileyButton class but then catch
 *      the events in the action method of the Container.
 * </OL>
 * <P>
 * Normally, the DSmileyButton's preferredSize (used,
 * for instance, by FlowLayout) is just big enough
 * to hold the dsmiley. However, if you give an explicit
 * resize or reshape call <B>before</B> adding the
 * DSmileyButton to the Container, this size will
 * override the defaults.
 * <P>
 * @author Marty Hall (hall@apl.jhu.edu)
 * @see Icon
 * @see DSmileyGrayFilter
 * @version 1.0 (1997)
 */

public class DSmileyButton extends DSmileyLabel 
{
	//----------------------------------------------------
	/** Default width of 3D border around dsmiley.
	 *  Currently 4.
	 * @see DSmileyLabel#setBorder
	 * @see DSmileyLabel#getBorder
	 */
	protected static final int defaultBorderWidth = 4;
	protected ActionListener actionListener = null;
	private String _dsmileyID;
	
	/** Default color of 3D border around dsmiley.
	 *  Currently a gray with R/G/B of 160/160/160.
	 *  Light grays look best.
	 * @see DSmileyLabel#setBorderColor
	 * @see DSmileyLabel#getBorderColor
	 */
	protected static final Color defaultBorderColor =  new Color(160, 160, 160);
	private boolean mouseIsDown = false;
	//----------------------------------------------------
	// Constructors
	/** Create an DSmileyButton with the default dsmiley.
	 * @see DSmileyLabel#getDefaultDSmileyString
	 */
	public DSmileyButton() 
	{
		super();
		setBorders();
		_dsmileyID=(getDefaultDSmileyString());
	}
	
	/** Create an DSmileyButton using the dsmiley at URL
	 *  specified by the string.
	 * @param dsmileyURLString A String specifying the URL
	 *        of the dsmiley.
	 */
	public DSmileyButton(String dsmileyURLString) 
	{
		super(dsmileyURLString);
		setBorders();
		_dsmileyID=(getDefaultDSmileyString());
	}
	
	/** Create an DSmileyButton using the dsmiley at URL
	 *  specified.
	 * @param dsmileyURL The URL of the dsmiley.
	 */
	public DSmileyButton(URL dsmileyURL) 
	{
		super(dsmileyURL);
		setBorders();
		_dsmileyID=(getDefaultDSmileyString());
	}
	
	/** Creates an DSmileyButton using the file in
	 *  the directory specified.
	 * @param dsmileyDirectory The URL of a directory
	 * @param dsmileyFile File in the above directory
	 */
	public DSmileyButton(URL dsmileyDirectory, String dsmileyFile) 
	{
		super(dsmileyDirectory, dsmileyFile);
		setBorders();
		_dsmileyID=(getDefaultDSmileyString());
	}
	
	/** Create an DSmileyButton using the dsmiley specified.
	 *  You would only want to use this if you already
	 *  have an dsmiley (e.g. created via createDSmiley).
	 * @param dsmiley The dsmiley.
	 */
	public DSmileyButton(Image dsmiley) 
	{
		super(dsmiley);
		setBorders();
		_dsmileyID=(getDefaultDSmileyString());
	}
	
	//----------------------------------------------------
	/** Draws the dsmiley with the border around it. If you
	 *  override this in a subclass, call super.paint().
	 */
	public void paint(Graphics g) 
	{
		super.paint(g);   
		if (grayDSmiley == null) 
			createGrayDSmiley(g);
		drawBorder(true);
	}
	
	public void addActionListener(ActionListener l) 
	{
		actionListener = AWTEventMulticaster.add(actionListener,l);
	}
	
	public void removeActionListener(ActionListener l) 
	{
		actionListener = AWTEventMulticaster.remove(actionListener, l);
	}
	
	//----------------------------------------------------
	// You only want mouseExit to repaint when mouse
	// is down, so you have to set that flag here.
	/** When the mouse is clicked, reverse the 3D border
	 *  and draw a dark-gray version of the dsmiley.
	 *  The action is not triggered until mouseUp.
     */
	public boolean mouseDown(Event event, int x, int y) 
	{
		mouseIsDown = true;
		Graphics g = getGraphics();
		int border = getBorder();
		if (hasExplicitSize())
			g.drawImage(grayDSmiley, border, border,
			getWidth()-2*border,
			getHeight()-2*border,
			this);
		else
			g.drawImage(grayDSmiley, border, border, this);
		drawBorder(false);
		return(true);
	}
	
	//----------------------------------------------------
	/** If cursor is still inside, trigger the action
	 *  event and redraw the dsmiley (non-gray, button
	 *  "out"). Otherwise ignore this.
	 */
	public boolean mouseUp(Event event, int x, int y) 
	{
		mouseIsDown = false;
		if (inside(x,y)) 
		{
			paint(getGraphics());
			event.id = Event.ACTION_EVENT;
			event.arg = (Object)getDSmiley();
			return(action(event, event.arg));
		} 
		else
			return(false);
	}
	
	//----------------------------------------------------
	/** Generated when the button is clicked and released.
	 *  Override this in subclasses to give behavior to
	 *  the button. Alternatively, since the default
	 *  behavior is to pass the ACTION_EVENT along to the
	 *  Container, you can catch events for a bunch of
	 *  buttons there.
	 * @see Component#action
	 */
	public boolean action(Event event, Object arg) 
	{
		System.out.println("Clicked on button for " +
			getDefaultDSmileyString() + ".");
			ActionEvent ae = new ActionEvent(this,0,getDSmileyID());
			if (actionListener != null) 
			{
				actionListener.actionPerformed(ae);
			}
		return(true);
	}
	
	//----------------------------------------------------
	/** If you move the mouse off the button while the
	 *  mouse is down, abort and do <B>not</B> trigger
	 *  the action. Ignore this if button was not
	 *  already down.
	 */
	public boolean mouseExit(Event event, int x, int y) 
	{
		if (mouseIsDown) 
			paint(getGraphics());
		return(true);
	}
	
	public String getDSmileyID()
	{
		return _dsmileyID;
	}

	public void setDSmileyID(String str)
	{
		_dsmileyID=str;
	}

	//----------------------------------------------------
	/** The darkness value to use for grayed dsmileys.
	 * @see #setDarkness
	 */
	public int getDarkness() 
	{
		return(darkness);
	}
	
	/** An int whose bits are combined via "and" ("&")
	 *  with the alpha, red, green, and blue bits of the
	 *  pixels of the dsmiley to produce the grayed-out
	 *  dsmiley to use when button is depressed.
	 *  Default is 0xffafafaf: af combines with r/g/b
	 *  to darken dsmiley.
	 */
	public void setDarkness(int darkness) 
	{
		this.darkness = darkness;
	}
	
	// Changing darker is consistent with regular buttons
	private int darkness = 0xffafafaf;
	
	//----------------------------------------------------
	/** The gray dsmiley used when button is down.
	 * @see #setGrayDSmiley
	 */
	public Image getGrayDSmiley() 
	{
		return(grayDSmiley);
	}
	
	/** Sets gray dsmiley created automatically from regular
	 *  dsmiley via an dsmiley filter to use when button is
	 *  depressed. You won't normally use this directly. 
	 */
	public void setGrayDSmiley(Image grayDSmiley) 
	{
		this.grayDSmiley = grayDSmiley;
	}
	
	private Image grayDSmiley = null;
	
	//----------------------------------------------------
	private void drawBorder(boolean isUp) 
	{
		Graphics g = getGraphics();
		g.setColor(getBorderColor());
		int left = 0;
		int top = 0;
		int width = getWidth();
		int height = getHeight();
		int border = getBorder();
		for(int i=0; i<border; i++) {
			g.draw3DRect(left, top, width, height, isUp);
			left++;
			top++;
			width = width - 2;
			height = height - 2;
		}
	}
	
	//----------------------------------------------------
	private void setBorders() 
	{
		setBorder(defaultBorderWidth);
		setBorderColor(defaultBorderColor);
	}
	
	//----------------------------------------------------
	// The first time the dsmiley is drawn, update() is
	// called, and the result does not come out correctly.
	// So this forces a brief draw on loadup, replaced
	// by real, non-gray dsmiley.
	
	private void createGrayDSmiley(Graphics g) 
	{
		ImageFilter filter = new DSmileyGrayFilter(darkness);
		ImageProducer producer =
			new FilteredImageSource(getDSmiley().getSource(),
			filter);
		grayDSmiley = createImage(producer);
		int border = getBorder();
		if (hasExplicitSize())
			prepareImage(grayDSmiley, getWidth()-2*border,
			getHeight()-2*border, this);
		else
			prepareImage(grayDSmiley, this);
		super.paint(g);
	}
	
	//----------------------------------------------------
}

//======================================================

/** Builds a dsmiley filter that can be used to gray-out
 *  the dsmiley.
 * @see DSmileyButton
 */
class DSmileyGrayFilter extends RGBImageFilter 
{
	//----------------------------------------------------
	private int darkness = 0xffafafaf;
	//----------------------------------------------------
	public DSmileyGrayFilter() 
	{
		canFilterIndexColorModel = true;
	}
	
	public DSmileyGrayFilter(int darkness) 
	{
		this();
		this.darkness = darkness;
	}
	
	//----------------------------------------------------
	public int filterRGB(int x, int y, int rgb) 
	{
		return(rgb & darkness);
	}
	
	//----------------------------------------------------
}
