/******************************************************/
/*          This java file is a part of the           */
/*                                                    */
/*      -  ADnD.com DSmileys v2.1b Plugin for -       */
/*                                                    */
/*                    -  PJirc -                      */
/*                                                    */
/*            - Plouf's Java IRC Client  -            */
/*                                                    */
/* Copyright (C)  2002 - 2006 Thema Ardholla Derentil */
/*                                                    */
/*         All contacts : thema@adnd.com              */
/*                                                    */
/*  This is free software; you can redistribute       */
/*  it and/or modify it under the terms of the GNU    */
/*  General Public License as published by the        */
/*  Free Software Foundation; version 2 or later of   */
/*  the License.                                      */
/*                                                    */
/*  It is distributed in the hope that it will        */
/*  be useful, but WITHOUT ANY WARRANTY; without      */
/*  even the implied warranty of MERCHANTABILITY or   */
/*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    */
/*  General Public License for more details.          */
/*                                                    */
/*  You should have received a copy of the GNU        */
/*  General Public License along with PJIRC; if       */
/*  not, write to the Free Software Foundation,       */
/*  Inc., 59 Temple Place, Suite 330, Boston,         */
/*  MA  02111-1307  USA                               */
/*                                                    */
/******************************************************/

package irc.plugin.adnd;

import irc.*;
import java.util.*;
import java.awt.*;
import irc.plugin.*;
import irc.gui.*;

/**
 * DSmiley Picker plugin.
 */
public class DSmileys extends Plugin implements Runnable
{
	private IRCConfiguration _ircConfig;
	private DSmileyConfiguration _dsConfig;
	private DSmileyPanel _dsmileyPanel;
	private IRCInterface _interface;
	private Thread _thread=null;
	private Container _container;
	private Component _currentGUI;
	private Dimension _sz;
 	private int _width=0;
	private int _height=0;
	private boolean _done=false;

	/**
	 * Mandatory constructor for all plugins.
	 * @param config the IRCConfiguration instance.
	 */
	public DSmileys(IRCConfiguration config)
	{
		super(config);
		_ircConfig=config;
	}

	public void load()
    {
		super.load();
		try
		{
			_dsConfig=new DSmileyConfigurationLoader(_ircConfiguration).loadDSmileyConfiguration();
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			throw new Error(ex.getMessage());
		}
		_interface=_ircApplication.getIRCInterface();
		System.out.println("Loaded Docked Smileys v2.1b:");
	} 

	public void run() 
	{
		Thread myThread=Thread.currentThread();
		//Create and open the ButtonPicker window.
		_dsmileyPanel=new DSmileyPanel(_dsConfig, _ircApplication, ScrollPane.SCROLLBARS_AS_NEEDED);
		Panel _p=new Panel();
		while (!_dsmileyPanel.loaded())
		{
			try 
			{
				_thread.sleep(10);
			}
			catch (InterruptedException e) 
			{
			}
		}
		try
		{
			_currentGUI=_interface.getComponent(); 
			_container=_currentGUI.getParent(); 
			_sz=_container.getSize();
			_container.validate();
		}
		catch (Exception ex)
		{
			ex.printStackTrace();
		}
		int _dsh=(int)_dsConfig.getI("height");
		if (_dsh <= 15 || _dsh >= (_sz.height-80))
		{
			_dsh=(int)Math.round(_sz.height*0.2);
		}
		int _cgh=(int)Math.round(_sz.height-_dsh);
		System.out.println("Width="+_sz.width+" Height="+_dsh);
		_container.removeAll();
		_currentGUI.setSize(_sz.width,_cgh);
		_dsmileyPanel.setSize(_sz.width,_dsh);	
		_p.setLayout(new BorderLayout());
		_p.add(_currentGUI,BorderLayout.CENTER);
		_p.add(_dsmileyPanel,BorderLayout.SOUTH);
		_p.show();
		_container.add(_p);
		_container.validate();
	}

	public synchronized void serverCreated(Server s)
	{
		if (_done)
		{
			return;
		}
		if (_thread == null) 
		{
			_thread = new Thread(this, "DSmileys");
			_thread.setDaemon(true);
			_thread.start();
		}
		_done=true;
	}
	
	public void unload()
    {
		_dsmileyPanel.release();
		_dsConfig=null;
		_dsmileyPanel=null;
		_container.removeAll();
		_dsmileyPanel=null;
		_container.setLayout(new FlowLayout());
		_container.add(_currentGUI);
		_currentGUI.setSize(_sz);
		_currentGUI.validate();
		_currentGUI.doLayout();
		System.out.println("Unloaded Docked Smileys v2.1b:");
		super.unload();
	}
}