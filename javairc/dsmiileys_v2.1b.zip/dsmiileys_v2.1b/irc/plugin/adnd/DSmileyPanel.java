/******************************************************/
/*          This java file is a part of the           */
/*                                                    */
/*      -  ADnD.com DSmileys v2.1b Plugin for -       */
/*                                                    */
/*                    -  PJirc -                      */
/*                                                    */
/*            - Plouf's Java IRC Client  -            */
/*                                                    */
/* Copyright (C)  2002 - 2006 Thema Ardholla Derentil */
/*                                                    */
/*         All contacts : thema@adnd.com              */
/*                                                    */
/*  This is free software; you can redistribute       */
/*  it and/or modify it under the terms of the GNU    */
/*  General Public License as published by the        */
/*  Free Software Foundation; version 2 or later of   */
/*  the License.                                      */
/*                                                    */
/*  It is distributed in the hope that it will        */
/*  be useful, but WITHOUT ANY WARRANTY; without      */
/*  even the implied warranty of MERCHANTABILITY or   */
/*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    */
/*  General Public License for more details.          */
/*                                                    */
/*  You should have received a copy of the GNU        */
/*  General Public License along with PJIRC; if       */
/*  not, write to the Free Software Foundation,       */
/*  Inc., 59 Temple Place, Suite 330, Boston,         */
/*  MA  02111-1307  USA                               */
/*                                                    */
/******************************************************/

package irc.plugin.adnd;

import irc.*;
import irc.plugin.*;
import java.awt.*;
import java.util.*;
import java.awt.event.*;


public class DSmileyPanel extends ScrollPane 
{
	protected DSmileyConfiguration _dsConfig;
	private IRCConfiguration _ircConfig;
	private IRCApplication _ircApplication;
	private DSmileyButtons _buttons=null;

  
	public DSmileyPanel(DSmileyConfiguration dsConfig,IRCApplication ircApplication,int scrollbarDisplayPolicy)
	{
		_dsConfig=dsConfig;
		_ircApplication=ircApplication;
		_ircConfig=_dsConfig.getIRCConfiguration();
		_buttons=new DSmileyButtons(_ircConfig, _dsConfig, _ircApplication);
		while (!_buttons.loaded())
		{
		}
		add(_buttons.getButtons());
		repaint();
		validate();
	}

	public boolean loaded()
	{
		return _buttons.loaded();
	}
	/**
	* Release this object. No further method call may be performed.
	*/
	public void release()
	{
		_dsConfig=null;
		_buttons=null;	
	}
	
}
