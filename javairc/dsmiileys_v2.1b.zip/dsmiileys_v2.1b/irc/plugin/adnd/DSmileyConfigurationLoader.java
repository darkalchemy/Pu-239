/******************************************************/
/*          This java file is a part of the           */
/*                                                    */
/*      -  ADnD.com DSmileys v2.1b Plugin for -       */
/*                                                    */
/*                    -  PJirc -                      */
/*                                                    */
/*            - Plouf's Java IRC Client  -            */
/*                                                    */
/* Copyright (C)  2002 - 2006 Thema Ardholla Derentil */
/*                                                    */
/*         All contacts : thema@adnd.com              */
/*                                                    */
/*  This is free software; you can redistribute       */
/*  it and/or modify it under the terms of the GNU    */
/*  General Public License as published by the        */
/*  Free Software Foundation; version 2 or later of   */
/*  the License.                                      */
/*                                                    */
/*  It is distributed in the hope that it will        */
/*  be useful, but WITHOUT ANY WARRANTY; without      */
/*  even the implied warranty of MERCHANTABILITY or   */
/*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    */
/*  General Public License for more details.          */
/*                                                    */
/*  You should have received a copy of the GNU        */
/*  General Public License along with PJIRC; if       */
/*  not, write to the Free Software Foundation,       */
/*  Inc., 59 Temple Place, Suite 330, Boston,         */
/*  MA  02111-1307  USA                               */
/*                                                    */
/******************************************************/

package irc.plugin.adnd;

import irc.*;
import irc.plugin.*;

import java.util.*;
import java.awt.*;

/**
 * Toolkit for Configuration creation.
 */
public class DSmileyConfigurationLoader
{
	private IRCConfiguration _config;
	private ParameterProvider _provider;
	/**
	* Create a new DSmileysConfigurationLoader.
	* @param config the irc configuration.
	*/
	public DSmileyConfigurationLoader(IRCConfiguration config)
	{
		_config=config;
		_provider=new PrefixedParameterProvider(_config.getParameterProvider(),"dsmileys:");
	}
	/**
	* Create a new DSmileysConfiguration object, using the given IRCConfiguration.
	* @return a new DSmileysConfiguration instance.
	* @throws Exception if an error occurs.
	*/
	public DSmileyConfiguration loadDSmileyConfiguration() throws Exception
	{
		return getDSmileyConfiguration();
	}
	
	private int getInt(String key,int def)
	{
		String v=getParameter(key);
		if(v==null) return def;
		try
		{
			return Integer.parseInt(v);
		}
		catch(Exception e)
		{
			return def;
		}
	}
	
	private String getParameter(String key)
	{
		return _provider.getParameter(key);
	}

	private String getString(String key,String def)
	{
		String v=getParameter(key);
		if(v==null) return def;
		return v;
	}

	private boolean getBoolean(String key,boolean def)
	{
		String v=getParameter(key);
		if(v==null) return def;
		v=v.toLowerCase().trim();
		if(v.equals("true") || v.equals("on") || v.equals("1")) return true;
		return false;
	}
	
	private DSmileyConfiguration getDSmileyConfiguration() throws Exception
	{
		DSmileyConfiguration config=new DSmileyConfiguration(_config);
		config.set("columns",getInt("columns",30));
		config.set("height",getInt("height",0));
		config.set("bkgcolor",getInt("bkgcolor",2));
		
		return config;
	}
}
