/******************************************************/
/*          This java file is a part of the           */
/*                                                    */
/*      -  ADnD.com DSmileys v2.1b Plugin for -       */
/*                                                    */
/*                    -  PJirc -                      */
/*                                                    */
/*            - Plouf's Java IRC Client  -            */
/*                                                    */
/* Copyright (C)  2002 - 2006 Thema Ardholla Derentil */
/*                                                    */
/*         All contacts : thema@adnd.com              */
/*                                                    */
/*  This is free software; you can redistribute       */
/*  it and/or modify it under the terms of the GNU    */
/*  General Public License as published by the        */
/*  Free Software Foundation; version 2 or later of   */
/*  the License.                                      */
/*                                                    */
/*  It is distributed in the hope that it will        */
/*  be useful, but WITHOUT ANY WARRANTY; without      */
/*  even the implied warranty of MERCHANTABILITY or   */
/*  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU    */
/*  General Public License for more details.          */
/*                                                    */
/*  You should have received a copy of the GNU        */
/*  General Public License along with PJIRC; if       */
/*  not, write to the Free Software Foundation,       */
/*  Inc., 59 Temple Place, Suite 330, Boston,         */
/*  MA  02111-1307  USA                               */
/*                                                    */
/******************************************************/

package irc.plugin.adnd;

import irc.*;
import irc.plugin.*;
import java.awt.*;
import java.net.*; 

// This appears in Core Web Programming from
// Prentice Hall Publishers, and may be freely used
// or adapted. 1997 Marty Hall, hall@apl.jhu.edu.

//======================================================
/**
 * A class for displaying dsmileys. It places the DSmiley
 * into a canvas so that it can moved around by layout
 * managers, will get repainted automatically, etc.
 * No mouseXXX or action events are defined, so it is
 * most similar to the Label Component.
 * <P>
 * By default, with FlowLayout the DSmileyLabel takes
 * its minimum size (just enclosing the dsmiley). The
 * default with BorderLayout is to expand to fill
 * the region in width (North/South), height
 * (East/West) or both (Center). This is the same
 * behavior as with the builtin Label class. If you
 * give an explicit resize or
 * reshape call <B>before</B> adding the
 * DSmileyLabel to the Container, this size will
 * override the defaults.
 * <P>
 * Here is an example of its use:
 * <P>
 * <PRE>
 * public class ShowDSmileys extends Applet {
 *   private DSmileyLabel dsmiley1, dsmiley2;
 *
 *   public void init() {
 *     dsmiley1 = new DSmileyLabel(getCodeBase(),
 *                             "some-dsmiley.gif");
 *     dsmiley2 = new DSmileyLabel(getCodeBase(),
 *                             "other-dsmiley.jpg");
 *     add(dsmiley1);
 *     add(dsmiley2);
 *   }
 * }
 * </PRE>
 *
 * @author Marty Hall (hall@apl.jhu.edu)
 * @see Icon
 * @see DSmileyButton
 * @version 1.0 (1997)
 */

public class DSmileyLabel extends Canvas
{
	//----------------------------------------------------
	// Instance variables.
	
	// The actual DSmiley drawn on the canvas. 
	private Image dsmiley;
	
	// A String corresponding to the URL of the dsmiley
	// you will get if you call the constructor with
	// no arguments.
	private static String defaultDSmileyString
		= "http://www.adnd.com/images/avatars/gallery/adnd.gif";
	
	// The URL of the dsmiley. But sometimes we will use
	// an existing dsmiley object (e.g. made by
	// createDSmiley) for which this info will not be
	// available, so a default string is used here.
	private String dsmileyString = "<Existing DSmiley>";
	
	// Turn this on to get verbose debugging messages. 
	private boolean debug = false;
	/** Amount of extra space around the dsmiley. */
	
	private int border = 0;
	
	/** If there is a non-zero border, what color should
	 *  it be? Default is to use the background color
	 *  of the Container.
	 */
	private Color borderColor = null;
	
	// Width and height of the Canvas. This is the
	//  width/height of the dsmiley plus twice the border.
	private int width, height;
	
	/** Determines if it will be sized automatically.
	 *  If the user issues a resize() or reshape()
	 *  call before adding the label to the Container,
	 *  or if the LayoutManager resizes before
	 *  drawing (as with BorderLayout), then those sizes
	 *  override the default, which is to make the label
	 *  the same size as the dsmiley it holds (after
	 *  reserving space for the border, if any).
	 *  This flag notes this, so subclasses that
	 *  override DSmileyLabel need to check this flag, and
	 *  if it is true, and they draw a modified dsmiley,
	 *  then they need to draw them based on the width
	 *  height variables, not just blindly drawing them
	 *  full size.
	 */
	private boolean explicitSize = false;
	private int explicitWidth=0, explicitHeight=0;
	
	// The MediaTracker that can tell if dsmiley has been
	// loaded before trying to paint it or resize
	// based on its size.
	private MediaTracker tracker;
	
	// Used by MediaTracker to be sure dsmiley is loaded
	// before paint & resize, since you can't find out
	// the size until it is done loading.
	private static int lastTrackerID=0;
	private int currentTrackerID;
	private boolean doneLoading = false;
	
	private Container parentContainer;
	
	//----------------------------------------------------
	/** Create an DSmileyLabel with the default dsmiley.
	 *
	 * @see #getDefaultDSmileyString
	 * @see #setDefaultDSmileyString
	 */
	// Remember that the funny "this()" syntax calls
	// constructor of same class
	public DSmileyLabel() 
	{
		this(defaultDSmileyString);
	}
	
	/** Create an DSmileyLabel using the dsmiley at URL
	 *  specified by the string.
	 *
	 * @param dsmileyURLString A String specifying the
	 *   URL of the dsmiley.
	*/
	public DSmileyLabel(String dsmileyURLString) 
	{
		this(makeURL(dsmileyURLString));
	}
	
	/** Create an DSmileyLabel using the dsmiley at URL
	 *  specified.
	 *
	 * @param dsmileyURL The URL of the dsmiley.
	 */
	public DSmileyLabel(URL dsmileyURL) 
	{
		this(loadDSmiley(dsmileyURL));
		dsmileyString = dsmileyURL.toExternalForm();
	}
	
	/** Create an DSmileyLabel using the dsmiley in the file
	 *  in the specified directory.
	 *
	 * @param dsmileyDirectory Directory containing dsmiley
	 * @param file Filename of dsmiley
	 */
	public DSmileyLabel(URL dsmileyDirectory, String file) 
	{
		this(makeURL(dsmileyDirectory, file));
		dsmileyString = file;
	}
	
	/** Create an DSmileyLabel using the dsmiley specified.
	 *  The other constructors eventually call this one,
	 *  but you may want to call it directly if you
	 *  already have an dsmiley (e.g. created via
	 *  createDSmiley).
	 *
	 * @param dsmiley The dsmiley
	 */
	public DSmileyLabel(Image dsmiley) 
	{
		this.dsmiley = dsmiley;
		tracker = new MediaTracker(this);
		currentTrackerID = lastTrackerID++;
		tracker.addImage(dsmiley, currentTrackerID);
	}
	
	//----------------------------------------------------
	/** Makes sure that the DSmiley associated with the
	 *  Canvas is done loading before returning, since
	 *  loadDSmiley spins off a separate thread to do the
	 *  loading. Once you get around to drawing the
	 *  dsmiley, this will make sure it is loaded,
	 *  waiting if not. The user does not need to call
	 *  this at all, but if several DSmileyLabels are used
	 *  in the same Container, this can cause
	 *  several repeated layouts, so users might want to
	 *  explicitly call this themselves before adding
	 *  the DSmileyLabel to the Container. Another
	 *  alternative is to start asynchronous loading by
	 *  calling prepareImage on the DSmileyLabel's
	 *  dsmiley (see getImage). 
	 *
	 * @param doLayout Determines if the Container
	 *   should be re-laid out after you are finished
	 *    waiting. <B>This should be true when called
	 *   from user functions</B>, but is set to false
	 *   when called from preferredSize to avoid an
	 *   infinite loop. This is needed when
	 *   using BorderLayout, which calls preferredSize
	 *   <B>before</B> calling paint.
	 */
	public void waitForDSmiley(boolean doLayout) 
	{
		if (!doneLoading) 
		{
			debug("[waitForDSmiley] - Resizing and waiting for "
			+ dsmileyString);
			try { tracker.waitForID(currentTrackerID); } 
			catch (InterruptedException ie) {} 
			catch (Exception e) 
			{ 
				System.out.println("Error loading "
				+ dsmileyString + ": "
				+ e.getMessage()); 
				e.printStackTrace(); 
			} 
			if (tracker.isErrorID(0)) 
				new Throwable("Error loading dsmiley "
			+ dsmileyString).printStackTrace();
			doneLoading = true;
			if (explicitWidth != 0)
				width = explicitWidth;
			else
				width = dsmiley.getWidth(this) + 2*border;
			if (explicitHeight != 0)
				height = explicitHeight;
			else
				height = dsmiley.getHeight(this) + 2*border;
	
			resize(width, height);
			debug("[waitForDSmiley] - " + dsmileyString + " is "
			+ width + "x" + height + ".");
			
			// If no parent, you are OK, since it will have
			// been resized before being added. But if
			// parent exists, you have already been added,
			// and the change in size requires re-layout. 
			if (((parentContainer = getParent()) != null) && doLayout) 
			{
				setBackground(parentContainer.getBackground());
				parentContainer.layout();
			}
		}
	}
	
	//----------------------------------------------------
	/** Moves the dsmiley so that it is <I>centered</I> at
	 *  the specified location, as opposed to the move
	 *  method of Component which places the top left
	 *  corner at the specified location.
	 *  <P>
	 *  <B>Note:</B> The effects of this could be undone
	 *  by the LayoutManager of the parent Container, if
	 *  it is using one. So this is normally only used
	 *  in conjunction with a null LayoutManager.
	 

	 * @param x The X coord of center of the dsmiley
	 *          (in parent's coordinate system)
	 * @param y The Y coord of center of the dsmiley
	 *          (in parent's coordinate system)
	 * @see java.awt.Component#move
	 */
	 
	public void centerAt(int x, int y) 
	{
		debug("Placing center of " + dsmileyString + " at ("
		+ x + "," + y + ")");
		move(x - width/2, y - height/2); 
	}
	
	//----------------------------------------------------
	/** Determines if the x and y <B>(in the DSmileyLabel's
	 *  own coordinate system)</B> is inside the
	 *  DSmileyLabel. Put here because Netscape 2.02 has
	 *  a bug in which it doesn't process inside() and
	 *  locate() tests correctly. 
	 */
	public synchronized boolean inside(int x, int y) 
	{
		return((x >= 0) && (x <= width)
			&& (y >= 0) && (y <= height));
	}
	
	//----------------------------------------------------
	/** Draws the dsmiley. If you override this in a
	 *  subclass, be sure to call super.paint.
	 */
	public void paint(Graphics g) 
	{
		if (!doneLoading)
			waitForDSmiley(true);
		else 
		{
			if (explicitSize)
				g.drawImage(dsmiley, border, border,
				width-2*border, height-2*border,
				this);
			else
				g.drawImage(dsmiley, border, border, this);
			drawRect(g, 0, 0, width-1, height-1,
				border, borderColor);
		}
	}
	
	//----------------------------------------------------
	/** Used by layout managers to calculate the usual
	 *  size allocated for the Component. Since some
	 *  layout managers (e.g. BorderLayout) may
	 *  call this before paint is called, you need to
	 *  make sure that the dsmiley is done loading, which
	 *  will force a resize, which determines the values
	 *  returned.
	 */
	public Dimension preferredSize() 
	{
		if (!doneLoading)
			waitForDSmiley(false);
		return(super.preferredSize());
	}
	
	//----------------------------------------------------
	/** Used by layout managers to calculate the smallest
	 *  size allocated for the Component. Since some
	 *  layout managers (e.g. BorderLayout) may
	 *  call this before paint is called, you need to
	 *  make sure that the dsmiley is done loading, which
	 *  will force a resize, which determines the values
	 *  returned.
	 */
	public Dimension minimumSize() 
	{
		if (!doneLoading)
			waitForDSmiley(false);
		return(super.minimumSize());
	}
	
	//----------------------------------------------------
	// LayoutManagers (such as BorderLayout) might call
	// resize or reshape with only 1 dimension of
	// width/height non-zero. In such a case, you still
	// want the other dimension to come from the dsmiley
	// itself.
	/** Resizes the DSmileyLabel. If you don't resize the
	 *  label explicitly, then what happens depends on
	 *  the layout manager. With FlowLayout, as with
	 *  FlowLayout for Labels, the DSmileyLabel takes its
	 *  minimum size, just enclosing the dsmiley. With
	 *  BorderLayout, as with BorderLayout for Labels,
	 *  the DSmileyLabel is expanded to fill the
	 *  section. Stretching GIF/JPG files does not always
	 *  result in clear looking dsmileys. <B>So just as
	 *  with builtin Labels and Buttons, don't
	 *  use FlowLayout if you don't want the Buttons to
	 *  get resized.</B> If you don't use any
	 *  LayoutManager, then the DSmileyLabel will also
	 *  just fit the dsmiley.
	 *  <P>
	 *  Note that if you resize explicitly, you must do
	 *  it <B>before</B> the DSmileyLabel is added to the
	 *  Container. In such a case, the explicit size
	 *  overrides the dsmiley dimensions.
	 *
	 * @see #reshape
	 */
	public void resize(int width, int height) 
	{
		if (!doneLoading) 
		{
			explicitSize=true;
			if (width > 0)
				explicitWidth=width;
			if (height > 0)
				explicitHeight=height;
		}
		super.resize(width, height);
	}
	
	/** Resizes the DSmileyLabel. If you don't resize the
	 *  label explicitly, then what happens depends on
	 *  the layout manager. With FlowLayout, as with
	 *  FlowLayout for Labels, the DSmileyLabel takes its
	 *  minimum size, just enclosing the dsmiley. With
	 *  BorderLayout, as with BorderLayout for Labels,
	 *  the DSmileyLabel is expanded to fill the
	 *  section. Stretching GIF/JPG files does not always
	 *  result in clear looking dsmileys. <B>So just as
	 *  with builtin Labels and Buttons, don't
	 *  use FlowLayout if you don't want the Buttons to
	 *  get resized.</B> If you don't use any
	 *  LayoutManager, then the DSmileyLabel will also   
	 *  just fit the dsmiley.
	 *  <P>
	 *  Note that if you resize explicitly, you must do
	 *  it <B>before</B> the DSmileyLabel is added to the
	 *  Container. In such a case, the explicit size
	 *  overrides the dsmiley dimensions.
	 *
	 * @see #resize
	 */
	public void reshape(int x, int y, int width, int height) 
	{
		if (!doneLoading) 
		{
			explicitSize=true;
			if (width > 0)
				explicitWidth=width;
			if (height > 0)
				explicitHeight=height;
		}
		super.reshape(x, y, width, height);
	}
	
	//----------------------------------------------------
	// You can't just set the background color to
	// the borderColor and skip drawing the border,
	// since it messes up transparent gifs. You
	// need the background color to be the same as
	// the container.
	
	/** Draws a rectangle with the specified OUTSIDE
	 *  left, top, width, and height.
	 *  Used to draw the border.
	 */
	protected void drawRect(Graphics g, int left, int top, int width, int height, int lineThickness, Color rectangleColor) 
	{
		g.setColor(rectangleColor);
		for(int i=0; i<lineThickness; i++) 
		{
			g.drawRect(left, top, width, height);
			if (i < lineThickness-1) 
			{  
				left = left + 1;
				top = top + 1;
				width = width - 2;
				height = height - 2;
			}
		}
	}
	
	public boolean isLoaded()
	{
		return doneLoading;
	}

	//----------------------------------------------------
	/** Calls System.out.println if the debug variable
	 *  is true; does nothing otherwise.
	 *
	 * @param message The String to be printed.
	 */
	protected void debug(String message) 
	{
		if (debug)
			System.out.println(message);
	}
	
	//----------------------------------------------------
	// Creates the URL with some error checking.
	private static URL makeURL(String s) 
	{
		URL u = null;
		try { u = new URL(s); }
		catch (MalformedURLException mue) 
		{
			System.out.println("Bad URL " + s + ": " + mue);
			mue.printStackTrace();
		}
		return(u);
	}
	
	private static URL makeURL(URL directory, String file)
	{
		URL u = null;
		try { u = new URL(directory, file); }
		catch (MalformedURLException mue) 
		{
			System.out.println("Bad URL " +
				directory.toExternalForm() +
				", " + file + ": " + mue);
			mue.printStackTrace();
		}
		return(u);
	}
	
	//----------------------------------------------------
	// Loads the dsmiley. Needs to be static since it is
	// called by the constructor.
	private static Image loadDSmiley(URL url) 
	{
		return(Toolkit.getDefaultToolkit().getImage(url));
	}
	
	//----------------------------------------------------  
	/** The DSmiley associated with the DSmileyLabel. */
	public Image getDSmiley() 
	{
		return(dsmiley);
	}
	
	//----------------------------------------------------
	/** Gets the border width. */
	public int getBorder() 
	{
		return(border);
	}
	
	/** Sets the border thickness. */
	public void setBorder(int border) 
	{
		this.border = border;
	}
	
	//----------------------------------------------------
	/** Gets the border color. */
	public Color getBorderColor() 
	{
		return(borderColor);
	}
	
	/** Sets the border color. */
	public void setBorderColor(Color borderColor) 
	{
		this.borderColor = borderColor;
	}
	
	//----------------------------------------------------
	// You could just call size().width and size().height,
	// but since we've overridden resize to record
	// this, we might as well use it.
	/** Gets the width (dsmiley width plus twice border). */
	public int getWidth() 
	{
		return(width);
	}
	
	/** Gets the height (dsmiley height plus 2x border). */
	public int getHeight() 
	{
		return(height);
	}
	
	//----------------------------------------------------
	/** Has the DSmileyLabel been given an explicit size?
	 *  This is used to decide if the dsmiley should be
	 *  stretched or not. This will be true if you
	 *  call resize or reshape on the DSmileyLabel before
	 *  adding it to a Container. It will be false
	 *  otherwise.
	 */
	protected boolean hasExplicitSize() 
	{
		return(explicitSize);
	}
	
	//----------------------------------------------------
	/** Returns the string representing the URL that
	 *  will be used if none is supplied in the
	 *  constructor.
	 */
	public static String getDefaultDSmileyString() 
	{
		return(defaultDSmileyString);
	}
	
	/** Sets the string representing the URL that
	 *  will be used if none is supplied in the
	 *  constructor. Note that this is static,
	 *  so is shared by all DSmileyLabels. Using this
	 *  might be convenient in testing, but "real"
	 *  applications should avoid it.
	 */
	public static void setDefaultDSmileyString(String file) 
	{
		defaultDSmileyString = file;
	}
	
	//----------------------------------------------------
	/** Returns the string representing the URL
	 *  of dsmiley.
	 */
	protected String getDSmileyString() 
	{
		return(dsmileyString);
	}
	
	//----------------------------------------------------
	/** Is the debugging flag set? */
	public boolean isDebugging() 
	{
		return(debug);
	}
	
	/** Set the debugging flag. Verbose messages
	 *  will be printed to System.out if this is true.
	 */
	public void setIsDebugging(boolean debug) 
	{
		this.debug = debug;
	}
	
	//----------------------------------------------------
}
